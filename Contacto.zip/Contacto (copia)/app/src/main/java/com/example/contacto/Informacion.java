package com.example.contacto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.contacto.R.layout.notification_action;

public class Informacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(notification_action);
    }
    //metodo el boton siguiente
    public void Editar (View view) {
        Intent editar = new Intent(this, MainActivity.class);
        startActivity(editar);
    }

}
