package com.example.contacto;

class NotificationImpl extendsNotification {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
